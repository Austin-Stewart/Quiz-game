import active_recall
import random
import time

main_body = active_recall.Quiz("questions.txt","answers.txt")
print(active_recall.count_lines("answers.txt"))
while True:
    question = main_body.add_question()
    if question.lower() == "n":
        break
    else:
        answer = main_body.add_answer()
while True:
    cont = input("Do you want to continue? Enter Y to continue, or N to stop")
    if cont.lower() == "y":
        random_index = random.randint(0,active_recall.count_lines("answers.txt"))
        question = open("questions.txt","r").readlines()[random_index]
        answer = open("answers.txt","r").readlines()[random_index]
        print(question)
        time.sleep(15)
        print(answer)
    elif cont.lower() == "n":
        break
