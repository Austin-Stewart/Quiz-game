def count_lines(file_path):
    lines_count = -1
    with open(file_path, 'r') as f:
        for l in f:
            lines_count = lines_count + 1

    return lines_count


class Quiz:
    def __init__(self, questions, answers):
        self.questions = questions
        self.answers = answers

    def add_answer(self):
        answer = input("Enter an answer to your question or n to stop")
        with open(self.answers, "a") as f:
            f.write(answer + "\n")
        return answer

    def add_question(self):
        question = input("Enter a question or n to stop")
        if question.lower() == "n":
            pass
        else:
            with open(self.questions, "a") as f:
                f.write(question + "\n")
        return question
